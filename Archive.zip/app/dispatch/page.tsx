"use client";

import { useMemo, useState } from "react";

import AppLayout from "@/components/layout/AppLayout";
import PageHeader from "@/components/ui/PageHeader";

import DispatchBoard from "@/components/dispatch/DispatchBoard";
import DispatchSearch from "@/components/dispatch/DispatchSearch";
import DispatchFilters from "@/components/dispatch/DispatchFilters";
import TransferDialog from "@/components/transfers/TransferDialog";

import { useTransfers } from "@/hooks/useTransfers";
import { useLookups } from "@/hooks/useLookups";

import { Transfer } from "@/types/transfer";

type DayFilter = "today" | "tomorrow" | "all";

export default function DispatchPage() {
  const {
    transfers,
    saveTransfer,
    updateDriver,
    updateVehicle,
  } = useTransfers();

  const {
    getDriverPhone,
    getDriverName,
    getVehicleName,
    getPartnerName,
  } = useLookups();

  const [editingTransfer, setEditingTransfer] =
    useState<Transfer | null>(null);

  const [dayFilter, setDayFilter] =
    useState<DayFilter>("today");

  const [statusFilter, setStatusFilter] =
    useState("All");

  const [search, setSearch] = useState("");

  const today = new Date()
    .toISOString()
    .split("T")[0];

  const tomorrowDate = new Date();
  tomorrowDate.setDate(
    tomorrowDate.getDate() + 1
  );

  const tomorrow = tomorrowDate
    .toISOString()
    .split("T")[0];

  const filteredTransfers = useMemo(() => {
    return transfers.filter((t) => {
      if (
        dayFilter === "today" &&
        t.date !== today
      )
        return false;

      if (
        dayFilter === "tomorrow" &&
        t.date !== tomorrow
      )
        return false;

      if (
        statusFilter !== "All" &&
        t.status !== statusFilter
      )
        return false;

      if (search.trim()) {
        const value = search.toLowerCase();

        const found = [
          t.transferNumber,
          t.clientName,
          t.phone,
          t.flight,
          t.pickup,
          t.destination,
          getDriverName(t.driverId),
          getVehicleName(t.vehicleId),
          getPartnerName(t.partnerId),
        ]
          .join(" ")
          .toLowerCase()
          .includes(value);

        if (!found) return false;
      }

      return true;
    });
  }, [
    transfers,
    dayFilter,
    statusFilter,
    search,
    today,
    tomorrow,
    getDriverName,
    getVehicleName,
    getPartnerName,
  ]);

  return (
    <AppLayout>
      <div className="space-y-6">

        <PageHeader
          title="Dispatch"
          subtitle="Manage daily transfers"
        />

        <DispatchSearch
          value={search}
          onChange={setSearch}
        />

        <DispatchFilters
          filter={statusFilter}
          onChange={setStatusFilter}
        />

        <div className="flex flex-wrap gap-3">

          <button
            onClick={() =>
              setDayFilter("today")
            }
            className={`rounded-lg px-4 py-2 font-medium transition ${
              dayFilter === "today"
                ? "bg-blue-600 text-white"
                : "bg-slate-100 hover:bg-slate-200"
            }`}
          >
            Today
          </button>

          <button
            onClick={() =>
              setDayFilter("tomorrow")
            }
            className={`rounded-lg px-4 py-2 font-medium transition ${
              dayFilter === "tomorrow"
                ? "bg-blue-600 text-white"
                : "bg-slate-100 hover:bg-slate-200"
            }`}
          >
            Tomorrow
          </button>

          <button
            onClick={() =>
              setDayFilter("all")
            }
            className={`rounded-lg px-4 py-2 font-medium transition ${
              dayFilter === "all"
                ? "bg-blue-600 text-white"
                : "bg-slate-100 hover:bg-slate-200"
            }`}
          >
            All
          </button>

        </div>

        <DispatchBoard
          transfers={filteredTransfers}
          onEdit={setEditingTransfer}
          getDriverPhone={getDriverPhone}
          onAssignDriver={updateDriver}
          onAssignVehicle={updateVehicle}
        />

        <TransferDialog
          transfer={editingTransfer}
          onSave={saveTransfer}
          hideTrigger
        />

      </div>
    </AppLayout>
  );
}