import { NextResponse } from "next/server";

import {
  getTransfersToNotify,
  markDriverNotified,
} from "@/services/notifications";

import { driverWhatsAppMessage } from "@/lib/helpers/driverWhatsApp";
import { sendWhatsApp } from "@/services/whatsapp";

export async function GET() {
  try {
    const transfers = await getTransfersToNotify();

    let sent = 0;

    for (const transfer of transfers) {
      const message = driverWhatsAppMessage({
        id: transfer.id,
        transferNumber: transfer.transfer_number,
        transferType: transfer.transfer_type,
        clientName: transfer.client_name,
        phone: transfer.phone,
        email: transfer.email,
        date: transfer.date,
        time: transfer.time,
        pickup: transfer.pickup,
        destination: transfer.destination,
        flight: transfer.flight,
        adults: transfer.adults,
        children: transfer.children,
        babySeats: transfer.baby_seats,
        boosterSeats: transfer.booster_seats,
        driver: transfer.driver,
        vehicle: transfer.vehicle,
        partner: transfer.partner,
        price: transfer.price,
        status: transfer.status,
        notes: transfer.notes,
        driverId: transfer.driver_id,
        vehicleId: transfer.vehicle_id,
        partnerId: transfer.partner_id,
      } as any);

      //
      // IMPORTANT:
      // Replace this with YOUR OWN WhatsApp number.
      // Example:
      // 385918833706
      //
      await sendWhatsApp(
        "385918833706",
        message
      );

      await markDriverNotified(transfer.id);

      sent++;

      console.log(
        `Notification sent for ${transfer.transfer_number}`
      );
    }

    return NextResponse.json({
      success: true,
      sent,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Unknown error",
      },
      {
        status: 500,
      }
    );
  }
}