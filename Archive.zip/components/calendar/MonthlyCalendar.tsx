"use client";

import Link from "next/link";
import { Transfer } from "@/types/transfer";

interface Props {
  year: number;
  month: number; // 0-11
  transfers: Transfer[];
}

const weekDays = [
  "Mon",
  "Tue",
  "Wed",
  "Thu",
  "Fri",
  "Sat",
  "Sun",
];

export default function MonthlyCalendar({
  year,
  month,
  transfers,
}: Props) {
  const firstDay = new Date(year, month, 1);

  const daysInMonth = new Date(
    year,
    month + 1,
    0
  ).getDate();

  const startDay =
    (firstDay.getDay() + 6) % 7;

  const cells: (number | null)[] = [];

  for (let i = 0; i < startDay; i++) {
    cells.push(null);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    cells.push(day);
  }

  while (cells.length % 7 !== 0) {
    cells.push(null);
  }

  const today = new Date();

  const todayString = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}-${String(
    today.getDate()
  ).padStart(2, "0")}`;

  return (
    <div className="rounded-2xl bg-white p-6 shadow">

      <div className="mb-4 grid grid-cols-7 gap-2">

        {weekDays.map((day) => (
          <div
            key={day}
            className="py-2 text-center text-sm font-semibold text-slate-500"
          >
            {day}
          </div>
        ))}

      </div>

      <div className="grid grid-cols-7 gap-2">

        {cells.map((day, index) => {
          if (day === null) {
            return (
              <div
                key={`empty-${index}`}
                className="aspect-square rounded-xl bg-slate-50"
              />
            );
          }

          const date = `${year}-${String(
            month + 1
          ).padStart(2, "0")}-${String(
            day
          ).padStart(2, "0")}`;

          const dayTransfers =
            transfers.filter(
              (t) => t.date === date
            );

          const count =
            dayTransfers.length;

          const revenue =
            dayTransfers.reduce(
              (sum, t) => sum + t.price,
              0
            );

          const assigned =
            dayTransfers.filter(
              (t) =>
                t.status ===
                  "Assigned" ||
                t.status ===
                  "Completed" ||
                t.status ===
                  "In Progress"
            ).length;

          let bg =
            "border-slate-200 bg-white";

          if (count > 0)
            bg =
              "border-green-200 bg-green-50";

          if (count > 10)
            bg =
              "border-yellow-300 bg-yellow-50";

          if (count > 20)
            bg =
              "border-red-300 bg-red-50";

          if (date === todayString) {
            bg =
              "border-blue-600 bg-blue-50";
          }

          return (
            <Link
              key={date}
              href={`/calendar?date=${date}`}
              className={`flex aspect-square flex-col rounded-xl border p-2 transition hover:scale-[1.02] hover:shadow ${bg}`}
            >
              <div className="flex items-center justify-between">

                <span className="text-sm font-bold">
                  {day}
                </span>

                {count > 0 && (
                  <span className="text-xs">
                    🚐
                  </span>
                )}

              </div>

              <div className="mt-2 flex-1">

                {count > 0 && (
                  <>
                    <p className="text-lg font-bold">
                      {count}
                    </p>

                    <p className="text-xs text-slate-500">
                      transfers
                    </p>

                    <p className="mt-2 text-xs text-green-700">
                      {assigned}/{count} assigned
                    </p>
                  </>
                )}

              </div>

              {revenue > 0 && (
                <div className="border-t pt-1 text-xs font-semibold text-slate-700">
                  €{revenue.toFixed(0)}
                </div>
              )}

            </Link>
          );
        })}

      </div>

    </div>
  );
}