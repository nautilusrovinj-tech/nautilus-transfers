/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

import TransferForm from "./TransferForm";

import { Transfer } from "@/types/transfer";

import {
  createEmptyTransfer,
  generateTransferNumber,
} from "@/lib/transfer";

interface Props {
  transfer?: Transfer | null;
  onSave: (transfer: Transfer) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
  hideTrigger?: boolean;
}

export default function TransferDialog({
  transfer,
  onSave,
  onDelete,
  hideTrigger = false,
}: Props) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [confirmDelete, setConfirmDelete] =
    useState(false);

  const [currentTransfer, setCurrentTransfer] =
    useState<Transfer>(createEmptyTransfer());

  const editing =
    transfer !== null &&
    transfer !== undefined;

  useEffect(() => {
    if (transfer) {
      setCurrentTransfer(transfer);
      setOpen(true);
    }
  }, [transfer]);

  function handleOpenChange(value: boolean) {
    setOpen(value);

    if (!value) {
      setCurrentTransfer(createEmptyTransfer());
    }
  }

  async function handleSave() {
    try {
      setSaving(true);

      await onSave(currentTransfer);

      setOpen(false);

      setCurrentTransfer(createEmptyTransfer());
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete() {
    if (!onDelete) return;

    try {
      setSaving(true);

      await onDelete(currentTransfer.id);

      setConfirmDelete(false);
      setOpen(false);

      setCurrentTransfer(createEmptyTransfer());
    } finally {
      setSaving(false);
    }
  }

  function handleDuplicate() {
    setCurrentTransfer({
      ...currentTransfer,
      id: crypto.randomUUID(),
      transferNumber:
        generateTransferNumber(),
      status: "New",
    });
  }

  return (
    <>
      {!hideTrigger && (
        <Button
          onClick={() => {
            setCurrentTransfer(
              createEmptyTransfer()
            );

            setOpen(true);
          }}
        >
          New Transfer
        </Button>
      )}

      <Dialog
        open={open}
        onOpenChange={handleOpenChange}
      >
        <DialogContent className="flex h-[94vh] w-[98vw] max-w-[1700px] flex-col overflow-hidden p-0">

          <DialogHeader className="border-b bg-white px-8 py-6">

            <DialogTitle className="text-2xl font-bold">

              {editing
                ? "Edit Transfer"
                : "New Transfer"}

            </DialogTitle>

            <p className="mt-1 text-sm text-slate-500">

              Manage transfer details,
              assignment and pricing.

            </p>

          </DialogHeader>

          <div className="flex-1 overflow-y-auto px-8 py-8">

            <TransferForm
              transfer={currentTransfer}
              setTransfer={setCurrentTransfer}
            />

          </div>

          <div className="flex items-center justify-between border-t bg-slate-50 px-8 py-5">

            <div className="flex gap-3">

              {editing && (
                <>
                  <Button
                    variant="secondary"
                    onClick={
                      handleDuplicate
                    }
                  >
                    Duplicate
                  </Button>

                  <Button
                    variant="destructive"
                    onClick={() =>
                      setConfirmDelete(
                        true
                      )
                    }
                  >
                    Delete
                  </Button>
                </>
              )}

            </div>

            <div className="flex gap-3">

              <Button
                variant="outline"
                onClick={() =>
                  setOpen(false)
                }
              >
                Cancel
              </Button>

              <Button
                onClick={handleSave}
                disabled={saving}
              >
                {saving
                  ? "Saving..."
                  : editing
                  ? "Update Transfer"
                  : "Save Transfer"}
              </Button>

            </div>

          </div>

        </DialogContent>
      </Dialog>

      <AlertDialog
        open={confirmDelete}
        onOpenChange={
          setConfirmDelete
        }
      >
        <AlertDialogContent>

          <AlertDialogHeader>

            <AlertDialogTitle>

              Delete Transfer?

            </AlertDialogTitle>

            <AlertDialogDescription>

              This action cannot be
              undone.

            </AlertDialogDescription>

          </AlertDialogHeader>

          <AlertDialogFooter>

            <AlertDialogCancel>
              Cancel
            </AlertDialogCancel>

            <AlertDialogAction
              onClick={handleDelete}
            >
              Delete
            </AlertDialogAction>

          </AlertDialogFooter>

        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}